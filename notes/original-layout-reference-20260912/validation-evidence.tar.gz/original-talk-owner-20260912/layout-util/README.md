# Original LayoutUtil source activation, 2026-09-12

The native utility now uses the complete available original translation unit and canonical reference header. This removes 82 initial compatibility definitions, redundant SimpleLayout overloads, the duplicate font/nerve utility files, duplicate resource queries, eight manager text/texture forwarding wrappers, and the host texture replacement method. The later text-height workaround and duplicate coordinate conversions are also removed. Exact initial and later cohorts are listed in removed-providers.json.

## Reference recovery and SDK contracts

Recovered first in decomp/src/Game/Util/LayoutUtil.cpp, then copied byte-for-byte to src/Game/Util/LayoutUtil.cpp:

- Anonymous showPaneRecursive / hidePaneRecursive: original visible bit and child traversal.
- MR::getLytTexMap / replacePaneTexture: original Picture RTTI and Material texture array access/copy. Replacement copies complete sampler/image state and retained encoded-resource ownership.
- Anonymous getTextDrawRectRecursive: visits children first, then unions the actual TextBox::GetTextDrawRect result with a temporary default DrawInfo. It carries whether any text box exists through all siblings. There is no visibility filter or host text geometry approximation.
- MR::setAnimFrameAndStopAdjustTextWidth / Height: use the union rectangle's width/height as the stopped animation frame. A textless subtree produces zero from the original default Rect.
- MR::calcTextBoxRectRecursive: transforms the union rectangle's two corners using the original pane-to-screen helper; a textless subtree clears both output vectors. It does not normalize or substitute another coordinate transform.

Actual SDK contracts recovered alongside this: Material GetTexture/SetTexture index assertions, mutable and const LinkList node/dereference assertions, Pane::SetVisible and its SetBit helper. The native nw4r::db::Panic boundary raises a diagnostic carrying original file/line/message. Texture factory ownership remains with the actual LayoutArchiveOwner/ResourceHolderService; no ResourceHolderManager fallback singleton was introduced.

## Evidence

The isolated original-compiler command and its successful output are reference-command.json and reference-compile.log. Retail comparison uses build/RMGK01/obj/Game/Util/LayoutUtil.o; objdiff.json and source-match-summary.json retain results:

| Recovered method | Match |
| --- | ---: |
| adjust text width | 100% |
| adjust text height | 100% |
| screen rectangle | 95.865% |
| get texture | 99.459% |
| replace texture | 99.643% |
| recursive text union | 70.451% |
| recursive show / hide | 53.319% / 58.933% |

The lower recursive scores reflect SDK iterator call/inlining and Rect assignment differences. The traversal, text-box test, DrawInfo lifetime, union comparisons and visible-bit behavior have been reviewed against retail assembly. These are functional source recoveries, not claims of high fuzzy matches for those three recursive helpers. LayoutUtil remains NonMatching in configure.py because further methods are not recovered.

All five native affected translation units compile successfully in isolation: LayoutUtil, LayoutUtilCompat, LayoutManagerCompat, OriginalLayoutResourceUtil, Nw4rDiagnostics. native-compile-results.json contains logs. source-manifest.json records file hashes. This is compilation evidence; the root agent owns integrated linked/runtime validation. The process agent was asked to extend its existing actual layout fixture for nested text and textless sizing.

## Remaining ownership and source frontiers

LayoutUtilCompat now has only ten providers: startAnim; createLytTexMap; showPane/hidePane; copyPaneScale and three scale/position combinations; emitEffect/deleteEffectAll. The simple original utility bodies can be recovered as a later bounded cohort. The texture factory must continue using the actual archive lifetime boundary, and layout effects still require their actual PaneEffectKeeper pipeline. In particular the current IfExecCalcAnim host scale/position helper does not yet express its original execution guard and should be replaced with its original source, not extended with another host rule.

The original resource creation queries now call the actual SingletonHolder<ResourceHolderManager>. A service-only synthetic fixture does not establish that process owner. No fallback owner was supplied. native-undefined.txt records all direct undefined symbols from the actual LayoutUtil object; most are the original SDK/text/layout owners being integrated concurrently by the process/root agents.
