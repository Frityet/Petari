# Original GX FIFO command-boundary breakpoints

This cohort implements `GXEnableBreakPt`, `GXDisableBreakPt`, and `GXSetBreakPtCallback` in the general Aurora FIFO/API boundary. No Game names, actor IDs, scene substitutions, or per-client queues are introduced.

## Source behavior

The native decoder backing buffer grows and is reclaimed after drain, so its addresses cannot be retained by the original DrawSyncManager's OS worker. Default FIFOs now own a stable 64 KiB logical address space for their lifetime, using the same modulo producer/read-address representation as supplied FIFO descriptors. Both are mapped to actual monotonic decoder cursors. The backing command storage remains independent; a logical FIFO descriptor does not claim to expose or import byte storage. Counts report actual outstanding command bytes, including values exceeding a logical ring's capacity; hardware overflow suspension remains unsupported.

Arming excludes command decoding while mapping the supplied GP address to its next occurrence at or after the actual decoded cursor. A passed address therefore means the next lap. At the requested complete command boundary, later commands remain unprocessed. A revision check suppresses an old interrupt if the guest disables or rearms while dispatch waits for CPU ownership. The interrupt is issued once per arm; leaving the breakpoint enabled leaves the decoder stopped. A callback may rearm the next address or disable it to resume. Installing a callback after an already handled callback-less hit does not fabricate another interrupt.

Producer progress is atomically readable independently of the GX producer thread. The `consumed` cursor records command decoding, while `completed` also waits for synchronous callback return. Drain waits for completed; rebinding rejects in-flight commands/callbacks. Ring offsets survive buffer growth and drained-storage reclamation. API attachment generations expire on FIFO shutdown. Empty/default/supplied FIFO attachment retains the existing limits and validation.

Root's coordinated callback work acquires the guest CPU execution gate before the callback mutex, restores allocation routing captured at callback registration, and releases guest CPU ownership while drain or shutdown waits for the FIFO worker. This allows original guest OS workers and deferred GX callbacks to share their existing scheduling/allocator authority.

## References and bounds

* `decomp/src/RVL_SDK/gx/GXFifo.c`: original breakpoint register writes disable then re-enable read/interrupt state; `GXBreakPointHandler` masks repeat interrupts while the read breakpoint remains active; callback setter returns the old callback.
* `dolphin/Source/Core/VideoCommon/CommandProcessor.cpp`: equality of current read address and configured breakpoint, not historical address lookup; command-idle includes the stopped-at-breakpoint state. Read-idle remains based on unread published bytes.
* Original `Game/System/DrawSyncManager.cpp::pushBreakPoint` saves the CPU write address after GXFlush, and its OS worker later arms that address.

This bounded implementation supports addresses at complete native GX command boundaries. The existing decoder rejects a cut inside command payloads. Partial-command fetch buffering is a separate unsupported boundary, explicitly accepted for this initial surface by the parent. Prefilled FIFO import, independent CPU/GP command routing, hardware write-gather behavior, and overflow/underflow suspension remain unsupported. Decoder idle/breakpoint status is not GPU-completion evidence; draw-sync/draw-done have their separate real renderer fence.

`GXFlush` publication behavior is unchanged in this cohort. Parent owns original DrawSyncManager activation and its integration validation; tests here do not claim gameplay or full original process readiness.

## Focused test coverage prepared

`aurora/tests/gx_fifo_breakpoint_test.cpp` is part of the existing `gx_fifo_tests` target and tests:

1. Stop before a following state command, actual read address/count/status, and resume on disable.
2. Rearm from the first callback at the next boundary; exactly two state observations.
3. Callback-less stop and exactly one new interrupt per rearm at the current address.
4. Saved default address stability through native backing growth, logical wrap, and drain.
5. Supplied ring with nonzero initial offset and a passed saved address mapping to its next lap.
6. Concurrent arm while a prior draw-done callback runs, using decoded rather than callback-completed cursor.
7. Unregister waits for an in-flight breakpoint callback.
8. Retirement/reinitialization of the default address owner and attachments.
9. Guest CPU gate defers callback dispatch; drain yields ownership and restores captured callback allocation routing.
10. Disabling under the guest CPU gate cancels the pending interrupt.
11. Rearming under the guest CPU gate replaces the pending interrupt without dispatching the old event.

The shared test fixture now initializes the actual FIFO owner before GXInit; production GXInit no longer initializes the Aurora renderer command stream itself. Parent owns targeted build/run receipts. No commit by this agent.

Final validation: parent built and ran the complete `gx_fifo_tests` target successfully, **285 tests passed**, including all **11 breakpoint tests**. Current receipts were read directly: `notes/original-draw-sync-lifetime-20260912/fifo-final-result.json` reports build_exit=0/test_exit=0; `fifo-final-tests.xml` records all eleven breakpoint cases with zero failures; `fifo-final-tests.log` reports 285/285 passing in 915 ms. `source-manifest.json` records the completed source hashes. These are CPU FIFO/SDK tests using renderer test support, not a real-GPU or gameplay claim.

After the independent lifecycle review, the callback lock is the actual cooperative SDK recursive OSMutex and actual callback entry saves/disables/restores the guest interrupt bit. Added two corresponding regression cases; see `independent-lifecycle-review.md`. Parent final reviewed receipt: **290/290 tests passed**, including all **13 breakpoint/callback tests** plus three ByteBuffer regressions. `fifo-reviewed-result.json` has build_exit=0/test_exit=0 and `fifo-reviewed-tests.xml` has no failures. Parent also passed the actual Metal original-manager proof (128 callbacks plus queue/worker retirement), depth-snapshot, draw-sync render-pass, and Z-texture targets; `reviewed-gpu-results.json` records exit0 for all four. These final receipts are under `notes/original-draw-sync-lifetime-20260912/`. The source manifest now reflects the reviewed sources.
