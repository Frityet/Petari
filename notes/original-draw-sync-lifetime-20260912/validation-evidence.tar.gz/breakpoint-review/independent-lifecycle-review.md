# Independent callback/lifecycle review

Reviewed the parent GuestThreadWaitScope, captured allocation routing, original DrawSyncManager, real manager fixture, and the mapped ByteBuffer correction.

## Findings fixed in shared Aurora callback boundary

1. **Yielding client callbacks can deadlock a guest-owned setter with a host mutex.** Original DrawSyncManager::drawSyncCallbackSub sends to its OS queue using OS_MESSAGE_BLOCK. A full queue causes OSSleepThread to release CPU ownership, while dispatch retained its host recursive callback mutex. A guest-owned unregister could then retain CPU ownership while waiting for that mutex, preventing the callback from returning. Callback dispatch and setters now use the actual recursive SDK OSMutex, whose lock wait releases CPU ownership through the existing SDK sleep queues. Zero initialization matches OSInitMutex's queue/owner/count state; intrusive owner links are set on first lock. No original sends changed. Added a full one-slot message queue test, a callback blocked sending into it, a guest-owned unregister, and a separate guest consumer which can run only if unregister's lock wait yields correctly.

2. **GX callbacks lacked the original interrupt-mask entry state.** GuestThreadExecutionScope serializes CPU access but does not itself mask interrupts. Retail CP/PE callbacks execute inside interrupt handlers, so OSDisableInterrupts called within them should return FALSE. A callback scope now saves, disables and restores the actual guest context's prior interrupt bit around each actual CP/PE callback. A test drives token, draw-done and breakpoint callbacks, verifies masked entry, intentionally leaves the bit masked, and checks that later decoder work and all three callbacks finish. This is guest interrupt-mask preservation, not full PowerPC OSContext emulation: OSGetCurrentContext/OSSetCurrentContext bodies remain absent.

The earlier revision check also remains necessary: a disabled/rearmed breakpoint must not dispatch its stale event after waiting to acquire guest CPU ownership.

## Required integration ordering

* Drain GPU/FIFO work and the original manager's message and breakpoint queues **before** clearing scene-heap callback pointers. Original drawSyncCallbackSub only enqueues the token acknowledgement while a non-null callback range matches. Clearing the pointer while its token is pending loses that acknowledgement and can strand the breakpoint queue. Heap callback retirement should therefore quiesce actual work while the callback owner is still valid, then clear references, then finalize/free that heap.
* Quiesce before DrawSyncManager::end. Its original destructor disables breakpoints, then puts an exit marker behind pending messages, then joins. An older queued pointer message could rearm a breakpoint before the worker reaches the exit marker. The current real-manager fixture correctly drains both queues first; its successful destructor does not prove arbitrary pending-work teardown safe.
* Captured allocation RoutingState preserves policy flags, not a heap pointer, selected-heap restoration, or ownership. Existing original JKR heap selection and retained heap domain must remain authoritative and alive through callback execution. The capture alone is not a retirement barrier.
* GuestThreadWaitScope correctly preserves thread-local nesting and interrupt bits while temporarily yielding CPU ownership; it does not erase those fields. Its documented scope must contain only a native wait which cannot itself invoke guest work. Scheduler-disabled waits correctly fail explicitly. No additional correctness problem found in the new scope under that contract.

## Test fixture and ByteBuffer

The manager fixture exercises original SDK queue/worker code and checks all 128 token callbacks through the requested actual GPU backend; it checks queue retirement before destruction. Callback assertions execute inside a noexcept FIFO path and thus intentionally fail hard on error. The fixture does not construct original GameSystem or prove its process initialization, and its native raw-allocation cleanup follows the original manager destructor rather than replacing it.

The ByteBuffer patch is correct for the observed borrowed staging issue: a zero-length append used to fall through resize(0) and overwrite capacity with zero. Early returns preserve the borrowed mapping. append_zeroes now zeros the newly exposed range even when reusing existing mapped/owned capacity, retaining the live prefix. Tests cover empty borrowed transfer, reused bytes, and owned growth. No material issue introduced by these changes was found.

Parent owns final build/GPU receipts. This review and its regression fix do not claim runtime owner integration or gameplay completion.

Final receipts inspected directly: `fifo-reviewed-result.json` build/test exits0 and `fifo-reviewed-tests.log` 290/290 passed. The full-queue cooperative-unregister and three callback interrupt-mask cases pass. `reviewed-gpu-results.json` records all four real-GPU target successes, including original DrawSyncManager; its run log confirms 128 GPU callbacks, queue turnover and thread retirement.
