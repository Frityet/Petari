#include <dolphin/os/OSFastCast.h>
#include <stdint.h>
#include <string.h>
#include <stdio.h>
int main(void) {
  volatile unsigned long long checksum = 0;
  for (uint64_t bits=0; bits<=UINT32_MAX; bits+=65521) {
    uint32_t word=(uint32_t)bits;
    float value;
    memcpy(&value,&word,sizeof(value));
    checksum += __OSf32tou8(value) + __OSf32tou16(value);
    checksum += __OSf32tos8(value) + __OSf32tos16(value);
  }
  puts("FastCast raw-float corpus passed UBSan and float-cast-overflow checks");
  return 0;
}
