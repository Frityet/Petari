#include "JSystem/JUtility/JUTVideo.hpp"
#include "JSystem/JUtility/JUTXfb.hpp"
#include "JSystem/JUtility/JUTDirectPrint.hpp"

#include <aurora/aurora.h>
#include <aurora/guest_thread.hpp>
#include <aurora/vi.hpp>

#include <array>
#include <chrono>
#include <cstdint>
#include <iostream>
#include <stdexcept>

namespace {
void require(bool value, const char* message) {
    if (!value) throw std::runtime_error(message);
}
unsigned sPreviousPre = 0;
unsigned sPreviousPost = 0;
unsigned sPreviousDraw = 0;
void previousPre(u32) { ++sPreviousPre; }
void previousPost(u32) { ++sPreviousPost; }
void previousDraw() { ++sPreviousDraw; }

void receiveRetrace(JUTVideo& video) {
    OSMessage message;
    while (OSReceiveMessage(video.getMessageQueue(), &message, OS_MESSAGE_NOBLOCK)) {}
    require(OSReceiveMessage(video.getMessageQueue(), &message, OS_MESSAGE_BLOCK),
            "original JUTVideo post callback must publish its actual queue message");
    require(reinterpret_cast<std::uintptr_t>(message) == VIGetRetraceCount(),
            "the original retrace message must preserve the complete count");
}

void exercise() {
    AuroraConfig config{};
    config.appName = "Original JUTVideo owner proof";
#if defined(__APPLE__)
    config.desiredBackend = BACKEND_METAL;
#else
    config.desiredBackend = BACKEND_VULKAN;
#endif
    config.allowCpuAdapter = true;
    config.windowWidth = 128;
    config.windowHeight = 96;
    config.vsync = false;
    config.pauseOnFocusLost = false;
    config.logLevel = LOG_WARNING;
    const auto info = aurora_initialize(0, nullptr, &config);
    require(info.backend == config.desiredBackend, "actual requested graphics backend is required");
    const aurora::os::GuestThreadExecutionScope execution;
    alignas(32) std::array<u8, 64 * 1024> fifoStorage{};
    GXInit(fifoStorage.data(), fifoStorage.size());
    GXRenderModeObj mode = GXNtsc480IntDf;
    mode.viTVmode = VI_TVMODE_NTSC_PROG;
    mode.fbWidth = mode.viWidth = 128;
    mode.efbHeight = mode.xfbHeight = mode.viHeight = 96;
    alignas(32) std::array<u8, 128 * 96 * 2> a{}, b{}, c{};
    auto* const direct = JUTDirectPrint::start();
    require(direct != nullptr, "actual original direct-print owner must exist before video callbacks");
    VIInit();
    VISetPreRetraceCallback(previousPre);
    VISetPostRetraceCallback(previousPost);
    const auto outerDraw = GXSetDrawDoneCallback(previousDraw);
    auto* const video = JUTVideo::createManager(&mode);
    require(video == JUTVideo::createManager(&mode) && video->getRenderMode() == &mode,
            "original video factory must retain one actual owner and borrowed render-mode record");
    auto* const xfb = JUTXfb::createManager(a.data(), b.data(), c.data());
    require(xfb->getBufferNum() == 3 && xfb->getDrawingXfb() == nullptr &&
                xfb->getDrawnXfb() == nullptr && xfb->getDisplayingXfb() == nullptr,
            "original XFB constructor must own three borrowed buffers and cleared indices");
    xfb->setDrawnXfbIndex(0);
    receiveRetrace(*video);
    require(aurora::vi::scanout_state().black && VIGetCurrentFrameBuffer() == nullptr,
            "first original startup retrace must stay black");
    receiveRetrace(*video);
    require(aurora::vi::scanout_state().black && VIGetCurrentFrameBuffer() == nullptr,
            "second original startup retrace must stay black");
    receiveRetrace(*video);
    require(VIGetCurrentFrameBuffer() == a.data() && xfb->getDisplayingXfbIndex() == 0,
            "original triple-buffer pre callback must publish the drawn framebuffer");
    receiveRetrace(*video);
    require(!aurora::vi::scanout_state().black && direct->mFrameBuffer == reinterpret_cast<u16*>(a.data()),
            "subsequent original callback must unblack VI and update direct-print backing");
    require(JUTVideo::getVideoInterval() != 0 && JUTVideo::getVideoLastTick() != 0,
            "actual retrace clock must update original JUT timing fields");

    // Hold the original draw-done state with its real FIFO command pending.
    // VI must continue scanning A until that callback has actually completed.
    aurora_update();
    require(aurora_begin_frame(), "actual GPU recording frame required");
    GXFifoObj fifo;
    require(GXGetCPUFifo(&fifo), "actual CPU FIFO pointer must be available");
    void* readPointer;
    void* writePointer;
    GXGetFifoPtrs(&fifo, &readPointer, &writePointer);
    GXEnableBreakPt(writePointer);
    JUTVideo::drawDoneStart();
    xfb->setDrawnXfbIndex(1);
    receiveRetrace(*video);
    require(xfb->getDisplayingXfbIndex() == 0 && VIGetCurrentFrameBuffer() == a.data(),
            "pending original draw completion must gate the next XFB exchange");
    GXDisableBreakPt();
    GXDrawDone();
    const auto deadline = std::chrono::steady_clock::now() + std::chrono::seconds(2);
    while (xfb->getDisplayingXfbIndex() != 1) {
        require(std::chrono::steady_clock::now() < deadline,
                "the SDK XFB getter must admit VI interrupts during an original guest polling loop");
    }
    require(xfb->getDisplayingXfbIndex() == 1 && VIGetCurrentFrameBuffer() == b.data(),
            "real GX completion callback must release the original XFB exchange");
    // This owner proof checks original VI/GX scheduling, not display-copy
    // rendering; black the output before submitting its empty host frame.
    JUTXfb::destroyManager();
    VISetBlack(TRUE);
    VIFlush();
    VIWaitForRetrace();
    aurora_end_frame();

    // Retail JUTVideo lasts until process exit and does not restore its GX
    // callback. The enclosing native owner must quiesce and retire that
    // borrowed registration before releasing the actual SDK objects.
    GXDrawDone();
    require(GXSetDrawDoneCallback(previousDraw) == JUTVideo::drawDoneCallback,
            "native lifetime must retire the actual borrowed original GX callback");
    JUTVideo::destroyManager();
    require(JUTXfb::getManager() == nullptr && JUTVideo::getManager() == nullptr,
            "actual SDK factories must clear their manager pointers on retirement");
    const auto pre = sPreviousPre, post = sPreviousPost;
    VIWaitForRetrace();
    require(sPreviousPre == pre + 1 && sPreviousPost == post + 1,
            "original JUT destructor must restore the preceding VI callback registrations");
    GXDrawDone();
    require(sPreviousDraw != 0, "restored GX callback must remain operational after JUT retirement");
    GXSetDrawDoneCallback(outerDraw);
    VISetPreRetraceCallback(nullptr);
    VISetPostRetraceCallback(nullptr);
    aurora::vi::shutdown();
    direct->changeFrameBuffer(nullptr, 0, 0);
    delete direct;
    JUTDirectPrint::sDirectPrint = nullptr;
    aurora_shutdown();
}
}
int main() {
    try {
        exercise();
        std::cout << "[ok] actual original JUTVideo/Xfb factories, retrace queue, draw-completion gating and callback retirement\n";
        return 0;
    } catch (const std::exception& error) {
        std::cerr << "[fail] original JUTVideo: " << error.what() << '\n';
        aurora_shutdown();
        return 1;
    }
}
