# Original display-owner prerequisites

This checkpoint establishes actual VI callbacks and GX display-copy selection, and exercises the complete original JUTVideo/JUTXfb/JUTDirectPrint cohort in an isolated executable. It does **not** activate MainLoopFramework or claim GameSystem startup, Gateway gameplay, CPU-authored XFB presentation, or faithful hardware GPU-abort behavior.

## Reference recovery

The missing ScreenPreserver::draw is recovered in `decomp/src/Game/Screen/ScreenPreserver.cpp` and matches retail `.text`, `.rodata`, and `.data` 100%. It creates the actual J2D graph, texture, and picture and draws the captured screen at the original dimensions; the signed EFB-height conversion is required by the retail instructions.

MainLoopFramework is an already complete original source cohort. Removed the Metrowerks-only runtime include, expressed its double-to-u64 watchdog duration with a standard explicit conversion, and normalized invalid `0f`/`1f` literals. Current original-compiler `.text` match is 99.91803%. The staged native copy alone guards two **unused** Flipper performance-counter reads under `!TARGET_PC`; no native hardware counters are fabricated. The actual recovery code remains present and still needs GXAbortFrame.

Original SDK compile corrections replace obsolete enum tag spellings with the existing GX typedefs in J2DPane/JUTPalette and include standard cstdarg in JUTAssert/JUTDirectPrint. `reference-source-manifest.json` freezes these seven reference files. ResourceHolderManager is a separate eighth frozen reference change, documented under `../original-resource-holder-manager-20260912/`.

`whole-cohort-reference-proof.json` and per-TU build/diff receipts preserve the full original-compiler probes: JUTVideo 100%, JUTXfb 100%, JUTDirectPrint 99.84163%, JUTPalette 99.66102%, JUTAssert 99.86264%, J2DPane 95.20113%, J2DPicture 99.97223% `.text`. These percentages do not imply that every pre-existing resource table or runtime path was independently audited.

## General native VI and GX boundaries

VI now owns a host retrace clock, the actual SDK retrace wait queue, and borrowed pre/post callback registrations. Each interrupt acquires the guest CPU, serializes callbacks with a cooperative recursive SDK mutex, preserves allocation routing, and disables/restores the caller's saved interrupt bit. It calls pre, latches flushed framebuffer/black state, calls post, then wakes retrace waiters. VIWaitForRetrace sleeps on this real queue rather than manufacturing a callback on the waiting caller. Callback unregister waits for an in-flight yielding callback; shutdown retires callbacks and joins the clock without retaining the guest CPU. VIInit is idempotent within a device lifetime.

Requested framebuffer, flushed next framebuffer, and scanning framebuffer are separate original states. The renderer now retains actual GPU GXCopyDisp textures by destination identity across frames. Presentation selects the VI current buffer rather than the newest display copy; black or unbound VI suppresses the game-texture blit. Existing Aurora clients that never initialize VI still use their established current-frame/EFB rendering path. Unknown or CPU-only selected XFBs fail explicitly. Cache retirement removes the corresponding display identity, and reuse creates new GPU contents.

The renderer/FIFO geometry read is an atomic published snapshot, not a guest CPU acquisition. The first actual JUT test deadlocked in GXDisableBreakPt: its caller held the guest CPU and waited for the FIFO execution lock while viewport decode held that lock and waited for VI geometry's guest scope. `jut-fixture-sample.txt` contains both real stacks. `configured_fb_size()` now reads the published width/height atomically; the VI frontend still owns its original configured mode.

GXRegs now provides original raw FIFO write macros through actual byte/word/float encoder operations, preserving big-endian command bytes. Original SDK ALIGN_PREV/ALIGN_NEXT are also available without the Game forced-include compatibility file.

## Validation

- Root's initial five VI tests passed 20 repetitions: `../original-main-loop-framework-20260912/vi-shared-direct-run.json`. After the actual JUT deadlock fix, a sixth test checks that the renderer can read configured geometry while the guest owns its CPU; the root rerun is pending at this note's creation.
- FIFO suite 291 tests passed including raw GXRegs bytes and actual BP command decode: `../original-main-loop-framework-20260912/gx_fifo_tests-shared-run.json`.
- Real Metal scanout passed red A, unflushed A, flushed green B, persistent earlier-frame copies, black suppression, retirement, same-address blue B replacement, and retained red A: `../original-main-loop-framework-20260912/gx_vi_scanout_render_test-fenced-run.json`. The initial retirement assertion correctly failed because GXDestroyCopyTex is itself queued; the test now fences before asserting completed retirement.
- `tests/OriginalJutVideoTests.cpp` directly links the three complete original SDK source copies and real Aurora/OS. No RuntimeContext or partial GameSystem is constructed. All source probes and the final link are recorded in `jut-fixture-native-compile.json` / `jut-fixture-link.json`. The final actual-GPU run passes in `jut-fixture-atomic-geometry-run.json` (exit 0): original singleton factories, two-retrace black startup, actual post queue, triple-buffer selection, real breakpoint-held pending draw completion, completed GX callback release, original polling through the SDK getter, and callback restoration. The staged native JUTXfb getter yields at its SDK boundary so a pure original polling loop admits VI interrupts; the original Game polling loop remains untouched. The staged native `delXfb` uses explicit operator delete for a void pointer.

## Explicit remaining boundaries

The current native JUTVideo implementation in production is still the prior RuntimeContext proxy. Replacing its header/source requires coherent actual display ownership in that runtime or true GameSystem startup; the tested original cohort remains staged in this notes directory. Do not globally activate it while the bounded renderer has no actual JUTXfb/MainLoop owner.

Retail JUTVideo's destructor restores VI callbacks but leaves its process-lifetime GX draw-done callback installed. The isolated fixture explicitly quiesces and restores this borrowed callback before deleting the actual objects. A native process owner must do the same. JUTVideo's static last-direct-print framebuffer also assumes a process lifetime and needs explicit borrowed-pointer retirement for independent repeated owner lifetimes. DirectPrint's CPU YUV writes require a real CPU-visible XFB/readback boundary before their output can be presented; a cached GPU copy alone does not cover that behavior.

VI currently approximates NTSC/EURGB60 field duration as 16,683,350 ns and PAL as 20,000,000 ns. Exact scan-mode timing, mode-register flush timing, time scaling/pause integration, NextField phase, and hardware OSContext semantics remain unproven. Current yielding VI/GX callback behavior is intentionally not changed to the scheduler-disabled OSAlarm ISR policy. The original single-buffer VI callback issues GXCopyDisp and still needs an actual rendering-thread ownership proof; this checkpoint validates triple-buffer callback selection.

MainLoop's remaining lower-owner frontier includes actual GPU abort/reset retirement across FIFO, unsubmitted encoder packets, texture/display identities, and pending readbacks. Clearing only FIFO commands would falsely report recovery. The staged native MainLoop already uses an actual pointer-width OSMessage temporary and an explicit 64-byte big-endian clear-Z texture; these architecture-only corrections still need the full MainLoop runtime proof before activation. OSAlarm/OSSleepTicks is owned by the parallel SDK worker.

`native-source-manifest.json` captures this agent's final source list. Shared CMake/Xmake files can receive coordinated OSAlarm/DVD source additions before root publication; their final aggregate manifest must therefore be refreshed by the root.
