# Original SDK alarms and sleeping threads

This adds the missing general Aurora OS alarm queue and `OSSleepTicks` boundary used by the original main loop. No Game code or per-actor timing path was added.

## Source basis

The implementation follows local retail `RVL_SDK/os/OSAlarm.s` and `OSThread.s` in `decomp/build/original-scenario-catalog-20260903/retail/asm/`, plus the original Wii declaration in `decomp/libs/RVL_SDK/include/revolution/os/OSAlarm.h`.

- `OSCreateAlarm` clears only handler and tag; the actual Wii record includes full-width native `userData` after start.
- One intrusive queue orders absolute deadlines, preserving insertion order at equal times. One-shot handlers become inactive before invocation; periodic alarms reinsert before invocation at the next phase aligned to their original start and skip missed periods.
- Cancellation removes the actual queued record. The native timer rechecks the queue after acquiring CPU ownership, so it never carries a borrowed alarm pointer across concurrent cancellation/storage retirement. Cancellation also waits for an in-flight callback to leave the CPU gate.
- The decrementer callback executes with interrupts masked, the scheduler disabled, a separate current `OSContext`, and the last live guest thread/context identity. Allocation routing is captured at registration; no guest heap owner is fabricated or extended.
- `OSSleepTicks` arms an actual stack alarm, suspends the actual SDK thread, resumes it from the alarm callback, and cancels on ordinary return, external early resume, or cancellation unwind. The original's 32-bit pointer-valued internal cancellation tag is replaced by actual C++ stack ownership; the full native thread pointer remains in user data. Public numeric tags are preserved.

## Native ownership and scope

A single owned worker and condition variable drive all alarms using the existing Aurora game clock. An intrusive clock-change listener wakes it when scale/pause/reset changes, including while an old deadline wait is in progress. The worker joins during service retirement, with the CPU released if the retiring caller owns it. Clock state and listener registry outlive the timer owner. No detached per-alarm threads or leaked owner are used.

The new `GuestInterruptExecutionScope` is deliberately restricted to nonblocking SDK interrupt handlers. Existing VI/GX callbacks retain their cooperative yielding path. Calling a blocking SDK wait with the scheduler disabled remains invalid. The native scheduler is cooperative: this supplies context identity and SDK ordering at existing CPU handoffs, not asynchronous host preemption or saved PowerPC register emulation.

## Evidence

`compile-command.json`, `compile.log`, `test-result.json`, and `test-run.log` record the isolated native compilation and execution. All 48 tests pass: 9 new alarm/sleep cases plus the existing 23 execution, 11 mutex (including death), and 5 message cases. The matching `sanitized-*` receipts run the same 48 cases with AddressSanitizer and UndefinedBehaviorSanitizer; all pass, with no sanitizer finding.

The additional `clock-regression-*` receipts include the existing game/native clock and OS time tests in the same executable: all 56 cases pass.

New cases verify one-shot context/scheduler/allocation routing; stable equal-deadline ordering; cancellation and address reuse; destroying a due queued alarm while its worker cannot yet acquire the CPU; cancellation while a callback is executing; numeric tag cancellation; periodic alignment and self-cancel; pause and scale changes during native waits; wakeup priority deferred until interrupt exit; actual sleep/early resume; and four canceled sleeping thread generations retiring their stack alarms.

This is SDK component evidence. It does not establish complete GameSystem/MainLoop startup or Gateway gameplay progression. Shared CMake/Xmake source activation and final integrated runs remain the root agent's lane.

## Independent review

`compat_audit` reviewed the final alarm/scope code read-only and found no additional material lock/lifetime issue. The review checked re-reading the alarm only after CPU acquisition, no one-shot pointer access after callback, gate-serialized cancellation, clock notification lock ordering, worker/listener retirement order, and clearing borrowed identities on native/managed thread retirement. Actual VI callback regression remains the root's shared `vi_tests` run; VI was not moved onto the new nonblocking interrupt scope.

## Shared-build include correction

Root changed the alarm source include from `time_internal.hpp` to `../../time_internal.hpp`, resolving the internal header relative to its actual source location. The isolated test commands supplied `-Iaurora/lib`, which had hidden this missing production include path. The source manifest is refreshed for this include-only correction. Root is rerunning the shared components and VI/GPU regressions; the earlier isolated receipts remain evidence for the same implementation before this include spelling correction.
