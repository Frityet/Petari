from pathlib import Path
import concurrent.futures,hashlib,json,os,shlex,subprocess,time
root=Path.cwd();out=root/'notes/original-dvd-callback-20260912';build=Path('/var/folders/4x/jzbfrvb10tq3ff4dwng8nzgm0000gn/T/petari-aurora-upstream-20260907-q3qrkgbx')
cmds=subprocess.check_output(['ninja','-t','commands','dvd_tests'],cwd=build,text=True).splitlines()
commands=[]
for source,stem in [('lib/dolphin/dvd/dvd.cpp','dvd-cmake'),('tests/test_dvd.cpp','test_dvd-cmake')]:
    line=next(x for x in cmds if x.endswith('/aurora/'+source) and ' -c ' in x)
    cmd=shlex.split(line)
    for flag,n in [('-MD',1),('-MT',2),('-MF',2)]:
        if flag in cmd:i=cmd.index(flag);del cmd[i:i+n]
    cmd[cmd.index('-o')+1]=str(out/(stem+'.o'));commands.append((stem,cmd))
def compile_one(item):
    name,cmd=item;p=subprocess.run(cmd,cwd=build,capture_output=True,text=True);(out/(name+'-compile.log')).write_text(p.stdout+p.stderr)
    return dict(command=cmd,exit=p.returncode)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:res=dict(compile=list(pool.map(compile_one,commands)))
assert all(x['exit']==0 for x in res['compile'])
line=next(x for x in cmds if ' -o tests/dvd_tests ' in x);link=shlex.split(line)[2:-2]
link[link.index('tests/CMakeFiles/dvd_tests.dir/test_dvd.cpp.o')]=str(out/'test_dvd-cmake.o')
link.insert(link.index('libaurora_dvd.a'),str(out/'dvd-cmake.o'))
binary=out/'dvd-callback-tests';link[link.index('-o')+1]=str(binary)
p=subprocess.run(link,cwd=build,capture_output=True,text=True);(out/'dvd-link.log').write_text(p.stdout+p.stderr);res.update(link_command=link,link_exit=p.returncode)
if p.returncode==0:
    env=dict(os.environ,SMGPC_REAL_DISC=str(root/'Super Mario Wii - Galaxy Adventure (Korea).rvz'))
    start=time.monotonic()
    with (out/'dvd-run.log').open('w') as log:
        try:p=subprocess.run([str(binary)],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=60);code=p.returncode
        except subprocess.TimeoutExpired:code='timeout'
    res.update(run_exit=code,seconds=time.monotonic()-start,binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest())
(out/'dvd-results.json').write_text(json.dumps(res,indent=2)+'\n');print({k:v for k,v in res.items() if k not in ['compile','link_command']},flush=True)
