from pathlib import Path
import concurrent.futures,hashlib,json,os,subprocess,time
root=Path.cwd();out=root/'notes/original-dvd-callback-20260912';templates=json.loads((out/'native-compile.json').read_text())
commands=[]
for index,path,name in [(0,'aurora/lib/dolphin/dvd/dvd.cpp','dvd-xmake'),(2,'tests/OriginalFileLoaderTests.cpp','FileLoader-callback'),(2,'src/Game/Util/FileUtil.cpp','FileUtil-callback')]:
    cmd=templates[index]['command'].copy()
    if index==0:cmd[cmd.index('-c')+1]=path
    else:cmd[-1]=path
    cmd[cmd.index('-o')+1]=str(out/(name+'.o'));commands.append((name,cmd))
def compile_one(item):
    name,cmd=item;p=subprocess.run(cmd,cwd=root,capture_output=True,text=True);(out/(name+'-compile.log')).write_text(p.stdout+p.stderr)
    return dict(command=cmd,exit=p.returncode,object=str(out/(name+'.o')))
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:res=dict(compile=list(pool.map(compile_one,commands)))
assert all(x['exit']==0 for x in res['compile'])
link=json.loads((root/'notes/original-talk-owner-20260912/obj-util/publication/csv-head-only-results.json').read_text())['link_command']
link=[x for x in link if not x.endswith('/csv-head-only.o') and not x.endswith('/ObjUtil-head-only.o')]
binary=out/'original-file-loader-callback-tests';link[link.index('-o')+1]=str(binary);link[3:3]=[x['object'] for x in res['compile']]
p=subprocess.run(link,cwd=root,capture_output=True,text=True);(out/'file-loader-link.log').write_text(p.stdout+p.stderr);res.update(link_command=link,link_exit=p.returncode)
if p.returncode==0:
    env=dict(os.environ,SMGPC_REAL_DISC=str(root/'Super Mario Wii - Galaxy Adventure (Korea).rvz'))
    start=time.monotonic()
    with (out/'file-loader-run.log').open('w') as log:
        try:p=subprocess.run([str(binary)],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=60);code=p.returncode
        except subprocess.TimeoutExpired:code='timeout'
    res.update(run_exit=code,seconds=time.monotonic()-start,binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest())
(out/'file-loader-results.json').write_text(json.dumps(res,indent=2)+'\n');print({k:v for k,v in res.items() if k not in ['compile','link_command']},flush=True)
