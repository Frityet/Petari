#include <revolution/types.h>
extern "C" void GXSetDrawSync(u16);
