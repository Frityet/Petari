#include "Game/Screen/CustomTagProcessor.hpp"
#include "Game/Screen/MessageEditorMessageTag.hpp"
#include "Game/Util/SoundUtil.hpp"
#include "Game/Util/StringUtil.hpp"
#include "nw4r/ut/TextWriterBase.h"
#include <cstddef>

extern "C" int swprintf(wchar_t*, size_t, const wchar_t*, ...);

namespace ReplaceTagProcessor {
    u32 exeLocalizeGroup(wchar_t*, const MessageEditorMessageTag&);
};  // namespace ReplaceTagProcessor

CustomTagProcessor::Operation CustomTagProcessor::exeDisplayGroup(nw4r::ut::Rect* rect, const MessageEditorMessageTag& tag, Context* context) {
    switch (tag.mMessage[1]) {
    case 0:
        return exeDisplayGroupWait(rect, tag.getParam16(0), context);
    case 2:
        return exeDisplayGroupOffset(rect, tag, context);
    case 3:
        return exeDisplayGroupCenter(rect, tag, context);
    case 1:
        return OPERATION_END_DRAW;
    default:
        return OPERATION_NO_CHAR_SPACE;
    }
}

CustomTagProcessor::Operation CustomTagProcessor::exeSoundGroup(nw4r::ut::Rect* rect, const MessageEditorMessageTag& tag, Context*) {
    if (rect != nullptr || mIsText || mAlphaCtrl.alpha() == 0) {
        return OPERATION_NO_CHAR_SPACE;
    }

    u8 mask = 1 << _31;
    if ((_30 & mask) != mask) {
        char soundName[256];
        s32 length = static_cast< s32 >(tag.getParamLength()) / 2;
        MR::convertUTF16ToASCII(soundName, tag.getParamPtr(0), length + 1);
        MR::startSystemSE(soundName, -1, -1);
        _30 |= static_cast< u8 >(1 << _31);
    }

    ++_31;
    return OPERATION_NO_CHAR_SPACE;
}

CustomTagProcessor::Operation CustomTagProcessor::exeFontSizeGroup(nw4r::ut::Rect*, const MessageEditorMessageTag& tag, Context* context) {
    nw4r::ut::TextWriterBase< wchar_t >* writer = context->writer;

    switch (tag.mMessage[1]) {
    case 0:
        writer->SetFontSize(0.75f * mFontWidth, 0.75f * mFontHeight);
        break;
    case 1:
        writer->SetFontSize(mFontWidth, mFontHeight);
        break;
    case 2:
        writer->SetFontSize(1.5f * mFontWidth, 1.5f * mFontHeight);
        break;
    }

    if (tag.mMessage[1] == 2 && mTextBox->GetTextPositionV() != 0) {
        writer->MoveCursorY(0.175f * mFontHeight);
    }

    return OPERATION_NO_CHAR_SPACE;
}

CustomTagProcessor::Operation CustomTagProcessor::exeSystemGroup(nw4r::ut::Rect* rect, const MessageEditorMessageTag& tag, Context* context) {
    switch (tag.mMessage[1]) {
    case 0:
        return exeSystemGroupColor(rect, tag.getParam8(0), context);
    case 2:
        return exeSystemGroupRuby(rect, tag, context);
    default:
        return OPERATION_NO_CHAR_SPACE;
    }
}

CustomTagProcessor::Operation CustomTagProcessor::exeLocalizeGroup(nw4r::ut::Rect* rect, const MessageEditorMessageTag& tag, Context* context) {
    wchar_t buffer[32];
    ReplaceTagProcessor::exeLocalizeGroup(buffer, tag);
    writeString(rect, buffer, context);
    return OPERATION_DEFAULT;
}

CustomTagProcessor::Operation CustomTagProcessor::exeNumberGroup(nw4r::ut::Rect* rect, const MessageEditorMessageTag& tag, Context* context) {
    wchar_t buffer[16];
    s32 number = *reinterpret_cast< const s32* >(tag.getParamPtr(0));

    switch (tag.mMessage[1]) {
    case 5:
        swprintf(buffer, 256, L"%02d", number);
    case 6:
        swprintf(buffer, 256, L"%03d", number);
    case 7:
        swprintf(buffer, 256, L"%04d", number);
    case 8:
        swprintf(buffer, 256, L"%05d", number);
    case 9:
        swprintf(buffer, 256, L"%06d", number);
    default:
        swprintf(buffer, 256, L"%d", number);
    }

    writeString(rect, buffer, context);
    return OPERATION_DEFAULT;
}

CustomTagProcessor::Operation CustomTagProcessor::exeStringGroup(nw4r::ut::Rect* rect, const MessageEditorMessageTag& tag, Context* context) {
    if (*reinterpret_cast< const u8* >(tag.getParamPtr(0)) == 0) {
        return OPERATION_DEFAULT;
    }

    writeString(rect, *reinterpret_cast< const wchar_t* const* >(tag.getParamPtr(0)), context);
    return OPERATION_DEFAULT;
}
