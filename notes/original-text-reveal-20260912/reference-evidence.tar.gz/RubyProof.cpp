#include "Game/System/Language.hpp"
#include "Game/Screen/CustomTagProcessor.hpp"
#include "Game/Screen/MessageEditorMessageTag.hpp"
#include "Game/Util/MemoryUtil.hpp"
#include "Game/Util/SystemUtil.hpp"
#include "nw4r/ut/TextWriterBase.h"
CustomTagProcessor::Operation CustomTagProcessor::exeSystemGroupRuby(nw4r::ut::Rect* rect, const MessageEditorMessageTag& tag, Context* context) {
    if (MR::getLanguage() != 0x10) {
        return OPERATION_NO_CHAR_SPACE;
    }
    s32 baseLength = tag.getParam8(0);
    const wchar_t* rubySource = tag.getParamPtr(1);
    s32 rubyLength = (tag.getParamLength() - 2) / 2;
    wchar_t base[32];
    wchar_t ruby[32];
    MR::copyMemory(ruby, rubySource, rubyLength * sizeof(wchar_t));
    ruby[rubyLength] = L'\0';
    MR::copyMemory(base, context->str + tag.getTagLength() / 2, baseLength * sizeof(wchar_t));
    base[baseLength] = L'\0';
    nw4r::ut::TextWriterBase< wchar_t >* original = context->writer;
    original->GetCharSpace();
    nw4r::ut::TextWriterBase< wchar_t > writer(*original);
    writer.SetDrawFlag(0x300);
    writer.SetLineSpace(0.0f);
    writer.SetCharSpace(2.0f);
    writer.SetFontSize(mRubyFontWidth, mRubyFontHeight);
    writer.SetTagProcessor(this);
    f32 baseWidth = original->CalcStringWidth(base, baseLength);
    f32 rubyWidth = writer.CalcStringWidth(ruby, rubyLength);
    if (rect == nullptr) {
        f32 difference = baseWidth - rubyWidth;
        if (difference > 0.0f) {
            f32 space = difference / (rubyLength + 1);
            writer.MoveCursorX(space);
            writer.SetCharSpace(2.0f + space);
        } else {
            writer.MoveCursorX(difference * 0.5f);
        }
        writer.MoveCursorY(3.0f - original->GetFontAscent());
        CustomTagAlphaCtrl alpha = mAlphaCtrl;
        mAlphaCtrl.mCharAlphaStep = baseLength * mAlphaCtrl.mCharAlphaStep / rubyLength;
        mAlphaCtrl.mCharIndex = rubyLength * mAlphaCtrl.mCharIndex / baseLength;
        writer.Print(ruby, rubyLength);
        mAlphaCtrl = alpha;
    }
    return OPERATION_NO_CHAR_SPACE;
}
