"""Compare retail and recovered PPC PrintImpl with the same deterministic SDK callbacks.
Unmodified retail instructions and freshly MW-compiled recovery execute in Unicorn.
Only Gekko paired-single register save/restore instructions are skipped; no core
PrintImpl branches/instructions are substituted. Callback seams record glyph output.
"""
import io,json,struct,math,re,hashlib
from pathlib import Path
from unicorn import Uc,UC_ARCH_PPC,UC_MODE_PPC32,UC_MODE_BIG_ENDIAN,UC_HOOK_CODE,UC_HOOK_MEM_INVALID
from unicorn.ppc_const import *
from elftools.elf.elffile import ELFFile
ROOT=Path(__file__).resolve().parents[2]
OUT=Path(__file__).resolve().parent
NAME='PrintImpl__Q34nw4r2ut17TextWriterBase<w>FPCwi'

def bits(f):return struct.unpack('>Q',struct.pack('>d',f))[0]
def unbits(n):return struct.unpack('>d',struct.pack('>Q',n))[0]
def f32(f):return struct.unpack('>f',struct.pack('>f',f))[0]
class Runner:
 def __init__(self,path,case):
  self.case=case;self.events=[];self.u=Uc(UC_ARCH_PPC,UC_MODE_PPC32|UC_MODE_BIG_ENDIAN)
  self.u.mem_map(0x80000000,0x2000000);self.u.reg_write(UC_PPC_REG_MSR,0x2000)
  self.callbacks={};self.symbols={};self.addr_names={}
  self.u.reg_write(UC_PPC_REG_2,0x80088000);self.u.reg_write(UC_PPC_REG_13,0x80098000)
  self.elf=ELFFile(io.BytesIO(path.read_bytes()));self.sections={}
  ordinary=0x80000000;sdata2=0x80080000;sdata=0x80090000
  for i,s in enumerate(self.elf.iter_sections()):
   if s.name.startswith('.text')or s.name in ('.rodata','.data','.sdata','.sdata2','.bss','.sbss','.sbss2','.ctors'):
    if s.name.endswith('data2')or s.name=='.sbss2':a=sdata2;sdata2+=(s['sh_size']+15)&~15
    elif s.name in ('.sdata','.sbss'):a=sdata;sdata+=(s['sh_size']+15)&~15
    else:a=ordinary;ordinary+=(s['sh_size']+4095)&~4095
    self.sections[i]=a
    if s['sh_type']!='SHT_NOBITS':self.u.mem_write(a,s.data())
  table=self.elf.get_section_by_name('.symtab');self.symaddr={};stub=0x800c0000
  for i,s in enumerate(table.iter_symbols()):
   if isinstance(s['st_shndx'],int)and s['st_shndx']in self.sections:a=self.sections[s['st_shndx']]+s['st_value']
   elif s.name=='mDefaultTagProcessor__Q34nw4r2ut17TextWriterBase<w>':a=0x80091000
   else:a=stub;stub+=4
   self.symaddr[i]=a
   if s.name:
    self.symbols[s.name]=a;self.addr_names[a]=s.name
  for sec in self.elf.iter_sections():
   if sec['sh_type']!='SHT_RELA'or sec['sh_info']not in self.sections:continue
   for rel in sec.iter_relocations():
    p=self.sections[sec['sh_info']]+rel['r_offset'];target=self.symaddr[rel['r_info_sym']]+rel['r_addend'];t=rel['r_info_type']
    if t==1:self.w32(p,target)
    elif t==10:self.w32(p,(self.r32(p)&0xfc000003)|((target-p)&0x03fffffc))
    elif t==4:self.w16(p,target)
    elif t==6:self.w16(p,(target+0x8000)>>16)
    elif t==5:self.w16(p,target>>16)
    elif t==109:
     reg=2 if 0x80080000<=target<0x80090000 else 13
     self.w32(p,(self.r32(p)&0xffe00000)|(reg<<16)|((target-self.g(reg))&0xffff))
    elif t in (24,26):pass
    else:raise RuntimeError(('relocation',t,table.get_symbol(rel['r_info_sym']).name))
  for name,a in self.symbols.items():
   if name!=NAME and(self.callback(name) is not None):self.callbacks[a]=self.callback(name)
  self.writer=0x81000000;self.font=0x81001000;self.processor=0x81002000;self.text=0x81003000;self.stack=0x81100000
  self.w32(self.font,0x81001100)
  for offset,name in [(0x1c,'fontbaseline'),(0x48,'fontwidth')]:
   self.w32(0x81001100+offset,stub);self.callbacks[stub]=getattr(self,name);stub+=4
  self.w32(self.processor,0x81002100)
  self.w32(0x80091000,0x81002100)
  for offset,name in [(0x0c,'process'),(0x10,'calcrect')]:
   self.w32(0x81002100+offset,stub);self.callbacks[stub]=getattr(self,name);stub+=4
  for off,val in [(0x24,case.get('scale_x',1)),(0x28,case.get('scale_y',1)),(0x2c,case.get('x',20)),(0x30,case.get('y',40)),(0x44,case.get('fixed',0)),(0x4c,case.get('limit',3.4028234663852886e38)),(0x50,case.get('space',2)),(0x54,0)]:self.wf(self.writer+off,val)
  self.u.mem_write(self.writer+0x42,bytes([case.get('alpha',211),int('fixed'in case)]))
  self.w32(self.writer+0x48,self.font);self.w32(self.writer+0x5c,case.get('flags',0));self.w32(self.writer+0x60,self.processor if case.get('custom',True)else 0x80091000)
  self.codes=case['codes'];self.u.mem_write(self.text,b''.join(struct.pack('>H',x)for x in self.codes+[0]*8))
  self.g(1,self.stack);self.g(3,self.writer);self.g(4,self.text);self.g(5,len(self.codes));self.u.reg_write(UC_PPC_REG_LR,0x800ff000)
  self.u.hook_add(UC_HOOK_CODE,self.hook)
 def g(self,n,v=None):
  reg=globals()['UC_PPC_REG_'+str(n)]
  if v is None:return self.u.reg_read(reg)
  self.u.reg_write(reg,v&0xffffffff)
 def f(self,n,v=None):
  reg=globals()['UC_PPC_REG_FPR'+str(n)]
  if v is None:return unbits(self.u.reg_read(reg))
  self.u.reg_write(reg,bits(float(v)))
 def r32(self,a):return struct.unpack('>I',self.u.mem_read(a,4))[0]
 def w32(self,a,v):self.u.mem_write(a,struct.pack('>I',v&0xffffffff))
 def w16(self,a,v):self.u.mem_write(a,struct.pack('>H',v&0xffff))
 def rf(self,a):return struct.unpack('>f',self.u.mem_read(a,4))[0]
 def wf(self,a,v):self.u.mem_write(a,struct.pack('>f',v))
 def callback(self,n):
  for key,fn in [('GetCursorX__',lambda:self.f(1,self.rf(self.g(3)+0x2c))),('GetCursorY__',lambda:self.f(1,self.rf(self.g(3)+0x30))),('SetCursorX__',lambda:self.wf(self.g(3)+0x2c,self.f(1))),('SetCursorY__',lambda:self.wf(self.g(3)+0x30,self.f(1))),('MoveCursorX__',lambda:self.wf(self.g(3)+0x2c,self.rf(self.g(3)+0x2c)+self.f(1))),('MoveCursorY__',lambda:self.wf(self.g(3)+0x30,self.rf(self.g(3)+0x30)+self.f(1))),('GetFont__',lambda:self.g(3,self.r32(self.g(3)+0x48))),('GetCharSpace__',lambda:self.f(1,self.rf(self.g(3)+0x50))),('GetCharStrmReader__',lambda:self.w32(self.g(3),0)),('GetCurrentPos__',lambda:self.g(3,self.r32(self.g(3)))),('Set__Q34nw4r2ut14CharStrmReader',lambda:self.w32(self.g(3),self.g(4))),('Next__Q34nw4r2ut14CharStrmReader',self.nextchar),('__ptmf_scall',self.nextchar),('AdjustCursor__',self.adjust),('CalcLineWidth__',self.linewidth),('reset__18CustomTagProcessor',self.reset),('alpha__18CustomTagAlphaCtrl',self.alpha),('SetAlpha__',self.setalpha),('UpdateVertexColor__',lambda:None),('Print__Q34nw4r2ut10CharWriter',self.printchar),('__ct__Q34nw4r2ut17TextWriterBase<w>FRC',lambda:self.u.mem_write(self.g(3),bytes(self.u.mem_read(self.g(4),0x64)))),('__ct__Q34nw4r2ut4Rect',lambda:self.u.mem_write(self.g(3),bytes(16))),('__dt__Q34nw4r2ut17TextWriterBase',lambda:None),('_savegpr_',lambda:None),('_restgpr_',lambda:None),('Panic__',lambda:(_ for _ in ()).throw(RuntimeError('retail panic')))]:
   if n.startswith(key):return fn
  return None
 def nextchar(self):
  p=self.r32(self.g(3));code=struct.unpack('>H',self.u.mem_read(p,2))[0];self.w32(self.g(3),p+2);self.g(3,code)
 def adjust(self):
  # The same deterministic cursor-adjustment SDK contract on both executions.
  x=self.rf(self.g(4));y=self.rf(self.g(5));flags=self.r32(self.writer+0x5c)
  width=self.case.get('align_width',self.measure(self.text,len(self.codes))) if flags&3 else 0
  if flags&0x30==0x10:x-=width/2
  elif flags&0x30==0x20:x-=width
  if flags&0x300==0x100:y-=10
  elif flags&0x300==0x200:y-=20
  self.wf(self.g(4),x);self.wf(self.g(5),y)
  first=self.measure(self.text,len(self.codes))
  self.wf(self.writer+0x2c,x+((width-first)/2 if flags&3==1 else width-first if flags&3==2 else 0))
  self.wf(self.writer+0x30,y+(0 if flags&0x300==0x300 else 7))
  self.f(1,width)
 def measure(self,p,n):
  width=0;have=False
  for i in range(n):
   c=struct.unpack('>H',self.u.mem_read(p+2*i,2))[0]
   if c in (0,10):break
   if c>=32:
    width+=self.case.get('space',2)if have else 0;width+=self.case.get('fixed',self.charwidth(c)*self.case.get('scale_x',1));have=True
  return width
 def linewidth(self):self.f(1,self.measure(self.g(4),self.g(5)))
 def charwidth(self,c):return 5+(c%4)
 def fontwidth(self):self.g(3,self.charwidth(self.g(4)))
 def fontbaseline(self):self.g(3,6)
 def reset(self):self.w32(self.g(3)+0x14,0);self.w16(self.g(3)+0x34,0)
 def alpha(self):
  index=self.r32(self.g(3)+0xc);self.g(3,max(0,min(255,220-index*43)))
 def setalpha(self):self.u.mem_write(self.g(3)+0x42,bytes([self.g(4)&255]))
 def printchar(self):
  w=self.g(3);c=self.g(4);x=self.rf(w+0x2c);y=self.rf(w+0x30)
  self.events.append({'code':c,'x':x,'y':y,'alpha':self.u.mem_read(w+0x42,1)[0]})
  width=self.case.get('fixed',self.charwidth(c)*self.case.get('scale_x',1));self.wf(w+0x2c,x+width);self.f(1,width)
 def process(self):
  c=self.g(4);ctx=self.g(5);w=self.r32(ctx)
  if c==10:self.wf(w+0x30,self.rf(w+0x30)+12);self.g(3,3)
  elif c==0:self.g(3,4)
  elif c==1:self.g(3,1)
  elif c==2:self.g(3,2)
  elif c==3:self.wf(w+0x2c,self.rf(w+0x2c)+9);self.g(3,0)
  elif c==4:self.g(3,4)
  else:self.g(3,0)
 def calcrect(self):
  rect=self.g(4);code=self.g(5);ctx=self.g(6);w=self.r32(ctx)
  width=9 if code==3 else 0
  for off,val in [(0,0),(4,0),(8,width),(12,12)]:self.wf(rect+off,val)
  self.wf(w+0x2c,self.rf(w+0x2c)+width);self.g(3,0)
 def hook(self,u,a,size,_):
  if a in self.callbacks:self.callbacks[a]();u.reg_write(UC_PPC_REG_PC,u.reg_read(UC_PPC_REG_LR));return
  word=self.r32(a)
  if word>>26 in (56,60):u.reg_write(UC_PPC_REG_PC,a+4)
 def run(self):
  try:self.u.emu_start(self.symbols[NAME],0x800ff000,count=20000)
  except Exception as e:raise RuntimeError((hex(self.u.reg_read(UC_PPC_REG_PC)),self.addr_names.get(self.u.reg_read(UC_PPC_REG_PC)),str(e))) from e
  if self.u.reg_read(UC_PPC_REG_PC)!=0x800ff000:raise RuntimeError('instruction limit')
  return {'width':self.f(1),'x':self.rf(self.writer+0x2c),'y':self.rf(self.writer+0x30),'alpha':self.u.mem_read(self.writer+0x42,1)[0],'char_index':self.r32(self.processor+0x14),'last_char':struct.unpack('>H',self.u.mem_read(self.processor+0x34,2))[0],'glyphs':self.events}

if __name__=='__main__':
 original=ROOT/'decomp/build/RMGK01/obj/Game/Screen/CustomTagProcessor.o';recovered=OUT/'PrintImpl.o'
 cases=[{'name':'plain','codes':[65,66,67]}, {'name':'default','codes':[65,66,67],'custom':False}, {'name':'empty','codes':[]}, {'name':'explicit-line','codes':[65,66,10,67,68]}, {'name':'wrap','codes':[65,66,67,68,69],'limit':16}, {'name':'oversize-first','codes':[65,66],'limit':1}, {'name':'control-space','codes':[65,1,66,2,67]}, {'name':'tag-wrap','codes':[65,3,66],'limit':12}, {'name':'end-draw','codes':[65,4,66]}, {'name':'fixed-width','codes':[65,66,67],'fixed':10,'limit':22}, {'name':'scaled','codes':[65,66,67],'scale_x':1.5,'scale_y':2,'limit':25}]
 for flags in [1,2,0x10,0x20,0x100,0x200,0x300,0x111,0x222,0x312]:cases.append({'name':f'alignment-{flags:x}','codes':[65,66,10,67],'flags':flags,'align_width':22})
 results=[]
 for case in cases:
  a=Runner(original,case).run();b=Runner(recovered,case).run();ok=a==b
  results.append({'case':case,'matched':ok,'retail':a,'recovered':b});print(case['name'],ok,flush=True)
  if not ok:print(a,b,flush=True)
 (OUT/'PrintImpl.differential.json').write_text(json.dumps({'original_sha256':hashlib.sha256(original.read_bytes()).hexdigest(),'recovered_sha256':hashlib.sha256(recovered.read_bytes()).hexdigest(),'results':results},indent=2)+'\n')
 assert all(x['matched']for x in results)
