#include "Game/Screen/CustomTagProcessor.hpp"
#include "Game/Screen/MessageEditorMessageTag.hpp"
#include "Game/Util/StringUtil.hpp"
#include "nw4r/ut/TextWriterBase.h"

CustomTagProcessor::Operation CustomTagProcessor::exeDisplayGroupWait(nw4r::ut::Rect* rect, u16 waitFrames, Context*) {
    if (rect == nullptr) {
        mAlphaCtrl.mWaitFrames += waitFrames;
    }

    return OPERATION_NO_CHAR_SPACE;
}

CustomTagProcessor::Operation CustomTagProcessor::exeDisplayGroupOffset(nw4r::ut::Rect*, const MessageEditorMessageTag& tag, Context* context) {
    nw4r::ut::TextWriterBase< wchar_t >* writer = context->writer;
    const wchar_t* string = context->str + tag.getSkipLength();
    nw4r::ut::Rect rect;

    if (mTextBox->GetTextPositionV() == 0) {
        writer->CalcStringRect(&rect, string, MR::getStringLengthWithMessageTag(string));
        writer->MoveCursorY((mTextBox->mSize.height - rect.GetHeight()) * 0.5f);
    }

    return OPERATION_NO_CHAR_SPACE;
}

CustomTagProcessor::Operation CustomTagProcessor::exeDisplayGroupCenter(nw4r::ut::Rect*, const MessageEditorMessageTag& tag, Context* context) {
    nw4r::ut::TextWriterBase< wchar_t > writer = *context->writer;
    const wchar_t* string = context->str + tag.getSkipLength();
    nw4r::ut::Rect rect;
    writer.CalcStringRect(&rect, string, MR::getStringLengthWithMessageTag(string));
    f32 offset = (mTextBox->mSize.width - rect.GetWidth()) * 0.5f;
    context->writer->MoveCursorX(offset);
    context->xOrigin += offset;
    return OPERATION_NO_CHAR_SPACE;
}
