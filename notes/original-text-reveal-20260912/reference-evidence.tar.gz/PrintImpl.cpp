#include "Game/Screen/CustomTagProcessor.hpp"
#include "nw4r/math/constant.h"
#include "nw4r/ut/TextWriterBase.h"
#include "nw4r/ut/inlines.h"

namespace nw4r {
    namespace ut {
        template <>
        f32 TextWriterBase< wchar_t >::PrintImpl(StreamType str, int length) {
            f32 xOrigin = GetCursorX();
            f32 yOrigin = GetCursorY();
            const bool bUseLimit = mWidthLimit < math::F_MAX;
            const f32 orgY = yOrigin;
            StreamType prevStreamPos = str;
            StreamType lineStart = str;
            bool bCharSpace = false;
            f32 textWidth = AdjustCursor(&xOrigin, &yOrigin, str, length);
            const f32 yOffset = orgY - GetCursorY();
            PrintContext< wchar_t > context = {this, str, xOrigin, yOrigin, 0};
            CharStrmReader reader = GetFont()->GetCharStrmReader();

            reader.Set(str);
            CustomTagProcessor* tagProcessor = nullptr;
            const u8 orgAlpha = GetAlpha();

            if (GetTagProcessor() != &mDefaultTagProcessor) {
                tagProcessor = static_cast< CustomTagProcessor* >(GetTagProcessor());
                tagProcessor->reset(str);
            }

            for (CharCode code = reader.Next(); reinterpret_cast< StreamType >(reader.GetCurrentPos()) - str <= length;) {
                if (code < ' ') {
                    context.str = reinterpret_cast< StreamType >(reader.GetCurrentPos());
                    context.flags = bCharSpace ? 0 : CONTEXT_NO_CHAR_SPACE;

                    if (bUseLimit && code != '\n' && prevStreamPos != lineStart) {
                        PrintContext< wchar_t > context2 = context;
                        TextWriterBase< wchar_t > myCopy = *this;
                        Rect rect;

                        context2.writer = &myCopy;
                        mTagProcessor->CalcRect(&rect, code, &context2);

                        if (rect.GetWidth() > 0.0f && myCopy.GetCursorX() - context.xOrigin > mWidthLimit) {
                            reader.Set(prevStreamPos);
                            code = '\n';
                            continue;
                        }
                    }

                    const TagProcessor::Operation operation = mTagProcessor->Process(code, &context);

                    if (operation == TagProcessor::OPERATION_NEXT_LINE) {
                        if (IsDrawFlagSet(HORIZONTAL_ALIGN_MASK, HORIZONTAL_ALIGN_CENTER)) {
                            const f32 width = CalcLineWidth(context.str, length - (context.str - str));
                            SetCursorX(context.xOrigin + (textWidth - width) * 0.5f);
                        } else if (IsDrawFlagSet(HORIZONTAL_ALIGN_MASK, HORIZONTAL_ALIGN_RIGHT)) {
                            const f32 width = CalcLineWidth(context.str, length - (context.str - str));
                            SetCursorX(context.xOrigin + (textWidth - width));
                        } else {
                            textWidth = Max(textWidth, GetCursorX() - context.xOrigin);
                            SetCursorX(context.xOrigin);
                        }

                        if (bUseLimit) {
                            lineStart = reinterpret_cast< StreamType >(reader.GetCurrentPos());
                        }
                        bCharSpace = false;
                    } else if (operation == TagProcessor::OPERATION_NO_CHAR_SPACE) {
                        bCharSpace = false;
                    } else if (operation == TagProcessor::OPERATION_CHAR_SPACE) {
                        bCharSpace = true;
                    } else if (operation == TagProcessor::OPERATION_END_DRAW) {
                        break;
                    }

                    reader.Set(context.str);
                } else {
                    if (tagProcessor != nullptr) {
                        SetAlpha(tagProcessor->mAlphaCtrl.alpha());
                        ++tagProcessor->mAlphaCtrl.mCharIndex;
                    }

                    const f32 y = GetCursorY();

                    if (bUseLimit && prevStreamPos != lineStart) {
                        const f32 x = GetCursorX();
                        const f32 charSpace = bCharSpace ? GetCharSpace() : 0.0f;
                        const f32 charWidth = IsWidthFixed() ? GetFixedWidth() : GetFont()->GetCharWidth(code) * GetScaleH();

                        if (charWidth + (charSpace + (x - xOrigin)) > mWidthLimit) {
                            reader.Set(prevStreamPos);
                            code = '\n';
                            continue;
                        }
                    }

                    if (bCharSpace) {
                        MoveCursorX(GetCharSpace());
                    }

                    bCharSpace = true;
                    MoveCursorY(-GetFont()->GetBaselinePos() * GetScaleV());
                    CharWriter::Print(code);

                    if (tagProcessor != nullptr) {
                        tagProcessor->mLastChar = code;
                    }

                    SetCursorY(y);
                }

                if (bUseLimit) {
                    prevStreamPos = reinterpret_cast< StreamType >(reader.GetCurrentPos());
                }

                code = reader.Next();
            }

            textWidth = Max(textWidth, GetCursorX() - context.xOrigin);

            if (IsDrawFlagSet(VERTICAL_ORIGIN_MASK, VERTICAL_ORIGIN_MIDDLE) ||
                IsDrawFlagSet(VERTICAL_ORIGIN_MASK, VERTICAL_ORIGIN_BOTTOM)) {
                SetCursorY(orgY);
            } else {
                MoveCursorY(yOffset);
            }

            if (tagProcessor != nullptr) {
                SetAlpha(orgAlpha);
            }

            return textWidth;
        }
    };  // namespace ut
};  // namespace nw4r
