import importlib.util,struct,json,hashlib
from pathlib import Path
spec=importlib.util.spec_from_file_location('oracle',Path(__file__).with_name('retail-differential.py'));mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
from unicorn.ppc_const import UC_PPC_REG_PC,UC_PPC_REG_LR
NAME='exeSystemGroupRuby__18CustomTagProcessorFPQ34nw4r2ut4RectRC23MessageEditorMessageTagPQ34nw4r2ut15PrintContext<w>'
class RubyRunner(mod.Runner):
 def __init__(self,path,case):
  super().__init__(path,dict(case,codes=[]));self.case=case
  self.ctx=0x81004000;self.tag=0x81005000
  base=case.get('base',[65,66,67]);ruby=case.get('ruby',[97,98]);length=8+2*len(ruby)
  payload=bytes([length,255,0,2,len(base)])+b''.join(struct.pack('>H',x)for x in ruby)+b'\0'+b''.join(struct.pack('>H',x)for x in base)
  self.u.mem_write(self.text,payload);self.w32(self.tag,self.text)
  self.w32(self.ctx,self.writer);self.w32(self.ctx+4,self.text);self.wf(self.ctx+8,20);self.wf(self.ctx+12,40);self.w32(self.ctx+16,0)
  alpha=struct.pack('>iiiiiiB3xff',2,3,17,case.get('index',5),7,19,1,case.get('step',0.25),0.5)
  self.u.mem_write(self.processor+8,alpha);self.initial_alpha=alpha
  self.wf(self.processor+0x40,case.get('ruby_width',5));self.wf(self.processor+0x44,5)
  self.g(3,self.processor);self.g(4,0 if not case.get('measure')else 0x81006000);self.g(5,self.tag);self.g(6,self.ctx)
 def callback(self,n):
  for key,fn in [('getLanguage__',lambda:self.g(3,self.case.get('language',16))),('getParam8__',lambda:self.g(3,self.u.mem_read(self.r32(self.g(3))+self.g(4)+4,1)[0])),('getParamPtr__',lambda:self.g(3,self.r32(self.g(3))+self.g(4)+4)),('getParamLength__',lambda:self.g(3,self.u.mem_read(self.r32(self.g(3)),1)[0]-6)),('getTagLength__',lambda:self.g(3,self.u.mem_read(self.r32(self.g(3)),1)[0]-2)),('copyMemory__',lambda:self.u.mem_write(self.g(3),bytes(self.u.mem_read(self.g(4),self.g(5))))),('SetCharSpace__',lambda:self.wf(self.g(3)+0x50,self.f(1))),('SetDrawFlag__',lambda:self.w32(self.g(3)+0x5c,self.g(4))),('SetLineSpace__',lambda:self.wf(self.g(3)+0x54,self.f(1))),('SetTagProcessor__',lambda:self.w32(self.g(3)+0x60,self.g(4))),('SetFontSize__',self.fontsize),('CalcStringWidth__',self.stringwidth),('GetFontAscent__',lambda:self.f(1,7)),('Print__Q34nw4r2ut17TextWriterBase',self.printstring)]:
   if n.startswith(key):return fn
  return super().callback(n)
 def fontsize(self):self.wf(self.g(3)+0x24,self.f(1)/10);self.wf(self.g(3)+0x28,self.f(2)/10)
 def stringwidth(self):
  w=self.g(3);p=self.g(4);n=self.g(5);codes=[struct.unpack('>H',self.u.mem_read(p+i*2,2))[0]for i in range(n)]
  width=sum(self.charwidth(c)*self.rf(w+0x24)for c in codes)+max(0,n-1)*self.rf(w+0x50)
  self.events.append({'measure':codes,'scale':self.rf(w+0x24),'space':self.rf(w+0x50),'width':width});self.f(1,width)
 def printstring(self):
  w=self.g(3);p=self.g(4);n=self.g(5);codes=[struct.unpack('>H',self.u.mem_read(p+i*2,2))[0]for i in range(n)]
  self.events.append({'print':codes,'x':self.rf(w+0x2c),'y':self.rf(w+0x30),'space':self.rf(w+0x50),'alpha_state':bytes(self.u.mem_read(self.processor+8,36)).hex()})
  # Simulate recursive rendering's mutation; caller must restore all alpha fields.
  self.u.mem_write(self.processor+8,bytes([0x5a])*36);self.f(1,123)
 def run(self):
  try:self.u.emu_start(self.symbols[NAME],0x800ff000,count=10000)
  except Exception as e:raise RuntimeError((hex(self.u.reg_read(UC_PPC_REG_PC)),str(e)))from e
  if self.u.reg_read(UC_PPC_REG_PC)!=0x800ff000:raise RuntimeError('instruction limit')
  return {'operation':self.g(3),'writer':bytes(self.u.mem_read(self.writer,0x64)).hex(),'alpha':bytes(self.u.mem_read(self.processor+8,36)).hex(),'alpha_restored':bytes(self.u.mem_read(self.processor+8,36))==self.initial_alpha,'events':self.events}
if __name__=='__main__':
 original=mod.ROOT/'decomp/build/RMGK01/obj/Game/Screen/CustomTagProcessor.o';recovered=mod.OUT/'RubyProof.o'
 cases=[{'name':'other-language','language':1},{'name':'measure','measure':True},{'name':'spread'},{'name':'center','base':[65],'ruby':[97,98,99,100],'ruby_width':10},{'name':'same-width','base':[65,66],'ruby':[65,66],'ruby_width':10},{'name':'negative-index','index':-3},{'name':'fractional-rescale','base':[65,66,67,68,69],'ruby':[97,98,99],'index':7,'step':0.3}]
 results=[]
 for case in cases:
  a=RubyRunner(original,case).run();b=RubyRunner(recovered,case).run();ok=a==b;print(case['name'],ok,flush=True)
  if not ok:print(a,b,flush=True)
  results.append({'case':case,'matched':ok,'retail':a,'recovered':b})
 (mod.OUT/'Ruby.differential.json').write_text(json.dumps({'original_sha256':hashlib.sha256(original.read_bytes()).hexdigest(),'recovered_sha256':hashlib.sha256(recovered.read_bytes()).hexdigest(),'results':results},indent=2)+'\n')
 assert all(x['matched']for x in results)
