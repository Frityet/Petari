from pathlib import Path
import concurrent.futures, hashlib, io, json, shutil, subprocess, tarfile, tempfile, time
root=Path.cwd(); out=root/'notes/original-system-utility-20260912'
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
checkout=Path(tempfile.mkdtemp(prefix='petari-system-head-audit-'))
for source,paths,dest in [(root,['src','tests'],checkout),(root/'aurora',['include'],checkout/'aurora')]:
    dest.mkdir(parents=True,exist_ok=True)
    with tarfile.open(fileobj=io.BytesIO(subprocess.check_output(['git','archive','HEAD',*paths],cwd=source))) as tar:
        tar.extractall(dest,filter='data')
manifest=json.loads((root/'notes/native-utility-publication-audit-20260912/GameSystemFunction-minimal-paths.json').read_text())
for item in manifest['files']:
    path=item['path']; target=checkout/path
    if path.endswith('StorySequencePlatformCompat.cpp'):
        before=target.read_bytes()
        remove=b'namespace GameSystemFunction {\n    bool setPermissionToCheckWiiRemoteConnectAndScreenDimming(bool) {\n        unavailable("Wii Remote connection and screen-dimming permission");\n    }\n}  // namespace GameSystemFunction\n'
        assert before.count(remove)==1
        target.write_bytes(before.replace(remove,b''))
    elif item['worktree_sha256'] is None:
        target.unlink()
    else:
        target.parent.mkdir(parents=True,exist_ok=True)
        data=(root/path).read_bytes(); assert hashlib.sha256(data).hexdigest()==item['worktree_sha256']
        target.write_bytes(data)
shutil.copyfile(root/'tests/OriginalWPadPauseTests.cpp',checkout/'tests/OriginalWPadPauseTests.cpp')
for item in manifest['files']:
    p=checkout/item['path']; item['staged_sha256']=hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else None
manifest.update(head=head,checkout=str(checkout))
(out/'source-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
base=json.loads((root/'notes/original-talk-owner-20260912/obj-util/ObjUtil-native-command.json').read_text())
base[base.index('-include')+1]=str(checkout/'src/compat/MetrowerksStdCompat.hpp')
files=[x['path'] for x in manifest['files'] if (checkout/x['path']).exists() and x['path'].endswith('.cpp')]+['tests/OriginalWPadPauseTests.cpp']
def compile_file(path):
    obj=out/(Path(path).stem+'-head-only.o'); cmd=base.copy(); cmd[cmd.index('-o')+1]=str(obj);cmd[-1]=path
    p=subprocess.run(cmd,cwd=checkout,capture_output=True,text=True)
    (out/(Path(path).stem+'-compile.log')).write_text(p.stdout+p.stderr)
    return dict(path=path,exit=p.returncode,command=cmd,object=str(obj))
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor: results=list(executor.map(compile_file,files))
res=dict(head=head,checkout=str(checkout),compile=results)
print([(x['path'],x['exit']) for x in results],flush=True)
if all(x['exit']==0 for x in results):
    link=json.loads((root/'notes/original-talk-owner-20260912/obj-util/publication/csv-head-only-results.json').read_text())['link_command']
    link=[x for x in link if not x.endswith('/csv-head-only.o') and not x.endswith('/ObjUtil-head-only.o')]
    binary=out/'original-system-wpad-tests';link[link.index('-o')+1]=str(binary)
    link[3:3]=[x['object'] for x in results if x['path'] in ['src/Game/System/GameSystemFunction.cpp','tests/OriginalWPadPauseTests.cpp']]
    p=subprocess.run(link,cwd=root,capture_output=True,text=True);(out/'link.log').write_text(p.stdout+p.stderr)
    res.update(link_command=link,link_exit=p.returncode)
    print('link',p.returncode,flush=True)
    if not p.returncode:
        start=time.monotonic();p=subprocess.run([str(binary)],cwd=root,capture_output=True,text=True,timeout=60)
        (out/'run.log').write_text(p.stdout+p.stderr)
        res.update(run_exit=p.returncode,seconds=time.monotonic()-start,binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest())
        print('run',p.returncode,flush=True)
(out/'results.json').write_text(json.dumps(res,indent=2)+'\n')
assert all(x['exit']==0 for x in results) and res.get('link_exit')==0 and res.get('run_exit')==0
