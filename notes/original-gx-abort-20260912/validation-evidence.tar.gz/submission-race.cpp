#include "gfx/command_epoch.hpp"
#include <barrier>
#include <cassert>
#include <memory>
#include <thread>
#include <vector>
int main() {
  constexpr int cycles = 10000;
  std::barrier step(3);
  std::shared_ptr<aurora::gfx::SubmissionState> state;
  bool committed = false;
  std::thread submit([&] {
    for (int i = 0; i != cycles; ++i) {
      step.arrive_and_wait();
      committed = state->commit();
      step.arrive_and_wait();
    }
  });
  std::thread abort([&] {
    for (int i = 0; i != cycles; ++i) {
      step.arrive_and_wait();
      aurora::gfx::abandon_command_epoch();
      step.arrive_and_wait();
    }
  });
  std::vector<std::shared_ptr<aurora::gfx::SubmissionState>> history;
  for (int i = 0; i != cycles; ++i) {
    state = std::make_shared<aurora::gfx::SubmissionState>();
    step.arrive_and_wait();
    step.arrive_and_wait();
    assert(state->is_submitted() == committed);
    assert(state->abandoned() == !committed);
    state->retire();
    history.push_back(state);
  }
  submit.join();
  abort.join();
  // Retained history cannot change outcome when its old registry slot is reused.
  for (auto& value : history) assert(value->is_submitted() != value->abandoned());
}
