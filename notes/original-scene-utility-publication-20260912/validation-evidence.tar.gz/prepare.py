from pathlib import Path
import hashlib, io, json, subprocess, tarfile, tempfile
root=Path.cwd();out=root/'notes/original-scene-utility-publication-20260912'
manifest=json.loads((root/'notes/scene-util-publication-audit-20260912/minimal-production-paths.json').read_text())
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert manifest['head']==head
checkout=Path(tempfile.mkdtemp(prefix='petari-scene-head-audit-'))
for source,paths,dest in [(root,['src','tests','script'],checkout),(root/'aurora',['include'],checkout/'aurora')]:
    dest.mkdir(parents=True,exist_ok=True)
    with tarfile.open(fileobj=io.BytesIO(subprocess.check_output(['git','archive','HEAD',*paths],cwd=source))) as tar:
        tar.extractall(dest,filter='data')
def original(path):return subprocess.check_output(['git','show','HEAD:'+path]).decode()
def replace_once(data,old,new):
    assert data.count(old)==1,(old,data.count(old));return data.replace(old,new)
def remove_body(data,signature):
    assert data.count(signature)==1,signature
    start=data.index(signature);opening=data.index('{',start);level=1;i=opening+1
    while level:
        if data[i]=='{':level+=1
        elif data[i]=='}':level-=1
        i+=1
    if data[i:i+1]=='\n':i+=1
    return data[:start]+data[i:]
removed=json.loads((root/'notes/original-talk-owner-20260912/scene-util/removed-provider-manifest.json').read_text())
partial={}
path='src/compat/StorySequencePlatformCompat.cpp';data=(root/path).read_text();before=original(path)
sig='    bool isStarCompleteAllGalaxy() {';start=before.index(sig);end=before.index('    void requestChangeScene(const char *) {',start)
# The entire gap only contains this EventUtil method and spacing.
data=replace_once(data,'    void requestChangeScene(const char *) {',before[start:end]+'    void requestChangeScene(const char *) {')
partial[path]=data
for path in ['src/compat/OriginalSceneCounterQueries.cpp','src/compat/GameActorPhysicsCompat.cpp']:
    data=original(path)
    for signature in removed[path]: data=remove_body(data,signature)
    if path.endswith('GameActorPhysicsCompat.cpp'):
        data=remove_body(data,'    [[noreturn]] void throw_scene_playing_result_unavailable() {')
    partial[path]=data
path='src/scene/AuthoredPlacementInstantiator.cpp';data=original(path).replace('PlacementZoneNameScope','PlacementZoneScope')
data=replace_once(data,'MR::getPlacedZoneId(placement.iter),\n                          placement.zone_name','MR::getPlacedZoneId(placement.iter)')
partial[path]=data
path='src/scene/NameObjLifecycleService.cpp';data=original(path).replace('PlacementZoneNameScope','PlacementZoneScope')
data=replace_once(data,'MR::getPlacedZoneId(placement->iter), placement->zone_name','MR::getPlacedZoneId(placement->iter)')
partial[path]=data
path='src/Game/xmake.lua';data=original(path)
line=next(x for x in data.splitlines(keepends=True) if 'remove_files("Util/SceneUtil.cpp")' in x)
partial[path]=replace_once(data,line,'')
for item in manifest['paths']:
    path=item['path'];target=checkout/path
    if item['current_sha256'] is None:
        target.unlink();continue
    data=(root/path).read_bytes();assert hashlib.sha256(data).hexdigest()==item['current_sha256'],path
    target.parent.mkdir(parents=True,exist_ok=True)
    if path in partial:data=partial[path].encode()
    target.write_bytes(data)
tests=['tests/AuthoredPlacementInstantiatorTests.cpp','tests/NameObjFactoryPlacementTests.cpp','tests/OriginalCollisionPartsOwnerTests.cpp','tests/SceneInitializationStateTests.cpp','tests/StorySequenceRealOrAbsentTests.cpp','tests/GameDataStarStorageTests.cpp']
for path in tests:
    data=(root/path).read_text()
    if path.endswith('StorySequenceRealOrAbsentTests.cpp'):
        before=original(path);a=before.index('    const auto game_xmake');b=before.index('    const auto boot',a)
        start=data.index('    const auto game_xmake');end=data.index('    const auto boot',start)
        data=data[:start]+before[a:b]+data[end:]
    (checkout/path).write_text(data)
    manifest['paths'].append(dict(path=path,action='required fixture migration or actual selected-file counter validation'))
for item in manifest['paths']:
    p=checkout/item['path'];item['staged_sha256']=hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else None
manifest.update(checkout=str(checkout),path_count=len(manifest['paths']))
(out/'source-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(checkout)
