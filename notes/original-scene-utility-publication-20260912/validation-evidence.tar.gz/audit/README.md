# Whole SceneUtil native publication boundary

Audited against root HEAD `7c93e95df8a335ee5d9dad74ca8277b726c1795c`. The working native `SceneUtil.cpp` byte-matches the current canonical reference. This audit made no production edits and ran no compiler or linker. Root subsequently authorized one existing fixture edit, `tests/GameDataStarStorageTests.cpp`, described below; that test is frozen for root's build lane.

## Publication scope

The coherent **source consolidation** set is 28 production paths in `minimal-production-paths.json`, plus necessary existing-test maintenance and the changing-save-owner counter proof. It removes the duplicate stage/scenario/phase/placement APIs and their copied state; it must be described as original-source consolidation with bounded counter evidence, not successful complete scene initialization. Existing shared Game/FileLoader/ARAM build results do not establish a real GameSystem controller or StageDataHolder at runtime.

The original reference/compiler proof remains in `notes/original-talk-owner-20260912/scene-util/`: ten recovered methods match exactly, hidden-star lookup matches96.8421%, next-linked-rail lookup91.77419%, and the full reference text96.619835%. This audit does not rerun or change those proofs. The source's `isStageKoopaVs1` correction remains the original retail Vs1 target, with no native-only behavior.

## Exact source and hunk ownership

`minimal-production-paths.json` is the complete staging map, including hashes of the current full files and explicit selective-hunk instructions.

- Four new headers: actual StageDataHolder, StageFileLoader and PlacedHiddenStarScenarioTable declarations, plus the smaller native PlacementZoneScope.
- Sixteen existing source/header edits: original SceneUtil, two JMapUtil files, ten native scene/provider files, SceneInitializationState header, and the remaining placement/lifecycle call sites. The JSON is authoritative for exact paths.
- Seven deleted files: the five entirely duplicated SceneUtil `.cpp` providers, obsolete StorySequencePlatformCompat state-binding header, and PlacementZoneNameScope header.
- One build hunk: remove only `remove_files("Util/SceneUtil.cpp")` from Game/xmake.

Critical selective files:

1. `StorySequencePlatformCompat.cpp`: remove the six SceneUtil methods and entire SceneStateBinding implementation/TLS/include. Preserve the pending EventUtil completion-method deletion and GameSystemFunction permission-stub deletion for their respective checkpoints. If GameSystemFunction has already landed, its deletion is simply in the new base.
2. `OriginalSceneCounterQueries.cpp`: remove only getCoinNum/getPurpleCoinNum/getPowerStarNum/isStageAstroLocation. Keep the two ScreenUtil requests and three EventUtil counters. **Keep its private getScenePlayingResult helper while the EventUtil getStarPieceNum body remains.** Staging the current whole file would remove that still-needed helper and unrelated MR methods.
3. `GameActorPhysicsCompat.cpp`: remove only incCoin/incPurpleCoin and the now-unused private scene-result rejection helper. Preserve the two pending ScreenUtil purple-counter deletions.
4. `AuthoredPlacementInstantiator.cpp`: only rename the placement-scope header/type and remove the copied zone-name constructor argument. Do not include the DrawSyncManagerLifetime include or transaction/commit/rollback additions.
5. `NameObjLifecycleService.cpp`: only rename the scope header/type and remove the copied zone-name argument in construct_and_init. Do not include any callback transaction changes to construction/init/error handling.

The other current diffs listed in the JSON belong to this SceneUtil cleanup. `fixture-path-hunks.json` separates the five earlier existing-test maintenance diffs from the newly authorized save-owner test. In particular, StorySequenceRealOrAbsentTests mixes SceneUtil owner requirements with EventUtil source-activation expectations; keep the EventUtil expectation changes out until EventUtil is activated. Source-order assertions are maintenance checks, not owner/runtime evidence.

## DrawSync and Talk are separable

No change to SceneObjHolderCompat, SceneObjHolderRuntime, SceneNameObjUtilCompat, SceneLifecycleService, SceneExecutionService, StageInitializationService, RuntimeContext, TalkDirectorLifetime or DrawSyncManagerLifetime is needed to compile the selected SceneUtil cleanup. Their current WIP concerns Talk ownership, callback tokens/transactions and retirement. `exclude-unrelated-wip.txt` lists these files explicitly. SceneObjHolderRuntime already includes SceneInitializationState and embeds a SceneInitializationBinding in HEAD, so the binding behavior updates through its existing type without importing Talk fields.

Changing the original SceneUtil provider does not justify copying any separate GameSystem singleton, scene controller, or StageDataHolder into those files. The data owners below remain real dependencies.

## Current unresolved owners

Fresh inspection of the existing shared SceneUtil object and Game archive still finds the same23 absent Game-level symbols; see `remaining-owner-symbols.json`. This is current object-provider inventory, not a new link result.

- StageDataHolder: getter plus17 methods, including table/child/rail lookup, start/camera data, owned-zone lookup and Japanese object names.
- StageFileLoader's makeStageArchiveName.
- The two original JMap rail readers.
- hasRetryGalaxySequence and the placed-hidden-star table query.

The StageDataHolder constructor remains missing in the reference source, and native source/factory activation is absent. Its reference findPlacedStageDataHolder and updateDataAddress cast actual row/data pointers to32-bit integers and classify them using `_E4/_E8` address bounds. A native owner must recover construction, retain the real archive/table/child graph, and express data ownership correctly at native pointer width; an invented StageDataHolder identity or a reinterpretation of the separate native StageResourceBinding catalog is not valid. Merely widening an address comparison must also respect how native JMapInfo backing is actually retained and laid out.

## Genuine process dependency of scene tests

SceneObjHolderBinding **already contains SceneInitializationBinding by value in HEAD**. With this cleanup, that member's constructor requires the real `SingletonHolder<GameSystem>::get()->mSceneController` before the scene-holder binding body starts. This affects every ordinary standalone SceneExecutionFixture and SceneObjHolderBinding fixture, even when the fixture only wants a genuine PlacementStateChecker or ScenePlayingResult. Bypassing the normal binding or installing a partly filled shell GameSystem would falsely supply the missing owner.

The real controller's initializeScene sets Init before creating the scene and its holder. The binding no longer invents Init. The actual process startup path must run before positive controller/placement phase tests; explicit original setters can then exercise phase transitions on that real controller, preserving its lifetime. The existing OriginalGameSystemStartupTests is the appropriate future integration location after `system->init()` returns with all required children. That fixture's full process lifetime is not part of this28-path source checkpoint.

Placement has an additional owner requirement: MR::getPlacedZoneId now asks StageDataHolder to find the holder owning the original row. The prior JMapInfo copied zone integer is no longer its authority. Therefore original NamePos, authored placement, camera rails/starts and normal stage initialization cannot be validated by their old retained-catalog fixtures until actual StageDataHolder owns those rows.

Existing fixture limitations:

- SceneInitializationStateTests returns77 after verifying missing-owner rejection when no real process exists. This is valid negative evidence only.
- OriginalSceneCounterOwnerTests still asserts that StageSession supplies current Mario start, scene-opening nerve state and stage-name predicates. It is stale under this migration and must not be used as a passing scene validation unchanged.
- OriginalNamePosOwnerTests calls MR::getGeneralPosNum against only StageResourceBinding; its actual NamePos objects do not supply the newly required StageDataHolder.
- SceneObjHolderRealOrAbsentTests and SceneExecutionFixture create genuine original scene objects but assume construction itself supplies Init. That assumption is removed; the process controller must exist first. Its EventDirector-absence assertion also belongs to a separate Event-owner migration.

## Bounded positive linked validation

Root authorized extending `tests/GameDataStarStorageTests.cpp`; the target is `smg-pc-game-data-star-storage-tests`, with the real Korean disc. It uses existing actual GameDataSession/UserFile/GameDataHolder owners and the real scenario catalog, without any GameSystem/controller/StageDataHolder construction or substitution.

The added SceneUtil calls verify MR::getPowerStarNum at existing state transitions: fresh selected file0; all real authored stars; each removed GrandStar; nested selected file0 and1; loaded serialized total; resetting the outer file while the inner file remains selected; removing/resetting the selected file; and restoration of the outer binding after inner retirement. Existing fixture checks retain catalog lifetime, original storage serialization, independent current/backup records, and heap reclamation. This proves the restored original counter forwarding follows changing real save owners and does not cache a previous file's state.

The fixture source is frozen and `git diff --check` passes; no build or run has been performed in this lane. Root owns clean-overlay compilation/linking and the run receipt. The result must stay explicitly scoped to original SceneUtil counter forwarding. It does not validate the controller/StageData families or Gateway progression.
