from pathlib import Path
import concurrent.futures, hashlib, json, os, subprocess, time
root=Path.cwd();out=root/'notes/original-scene-utility-publication-20260912';m=json.loads((out/'source-manifest.json').read_text());checkout=Path(m['checkout'])
base=json.loads((root/'notes/original-talk-owner-20260912/obj-util/ObjUtil-native-command.json').read_text());base[base.index('-include')+1]=str(checkout/'src/compat/MetrowerksStdCompat.hpp')
files=[x['path'] for x in m['paths'] if x['staged_sha256'] and x['path'].endswith('.cpp')]
def compile_file(path):
    obj=out/(Path(path).stem+'-head-only.o');cmd=base.copy();cmd[cmd.index('-o')+1]=str(obj);cmd[-1]=path
    p=subprocess.run(cmd,cwd=checkout,capture_output=True,text=True)
    (out/(Path(path).stem+'-compile.log')).write_text(p.stdout+p.stderr)
    return dict(path=path,exit=p.returncode,command=cmd,object=str(obj))
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:results=list(executor.map(compile_file,files))
res=dict(head=m['head'],checkout=str(checkout),compile=results)
print([(x['path'],x['exit']) for x in results],flush=True)
if all(x['exit']==0 for x in results):
    template=json.loads((root/'notes/original-talk-owner-20260912/obj-util/publication/csv-head-only-results.json').read_text())['link_command']
    template=[x for x in template if not x.endswith('/csv-head-only.o') and not x.endswith('/ObjUtil-head-only.o')]
    cases=[('star-counter',['SceneUtil','GameDataStarStorageTests'],0),('unowned-controller',['SceneUtil','SceneInitializationState','SceneInitializationStateTests'],77)]
    res['runtime']=[]
    for name,objects,expected in cases:
        link=template.copy();binary=out/name;link[link.index('-o')+1]=str(binary)
        link[3:3]=[str(out/(x+'-head-only.o')) for x in objects]
        p=subprocess.run(link,cwd=root,capture_output=True,text=True);(out/(name+'-link.log')).write_text(p.stdout+p.stderr)
        case=dict(name=name,link_command=link,link_exit=p.returncode,expected=expected);res['runtime'].append(case)
        print(name,'link',p.returncode,flush=True)
        if not p.returncode:
            env=dict(os.environ,SMGPC_REAL_DISC=str(root/'Super Mario Wii - Galaxy Adventure (Korea).rvz'))
            start=time.monotonic();p=subprocess.run([str(binary)],cwd=root,env=env,capture_output=True,text=True,timeout=60)
            (out/(name+'-run.log')).write_text(p.stdout+p.stderr)
            case.update(run_exit=p.returncode,seconds=time.monotonic()-start,binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest())
            print(name,'run',p.returncode,flush=True)
(out/'results.json').write_text(json.dumps(res,indent=2)+'\n')
assert all(x['exit']==0 for x in results) and all(x['link_exit']==0 and x.get('run_exit')==x['expected'] for x in res['runtime'])
