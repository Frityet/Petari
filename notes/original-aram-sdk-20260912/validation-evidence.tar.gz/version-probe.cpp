#include <dolphin/os.h>
int main() { OSRegisterVersion("SDK version 100% ready"); }
