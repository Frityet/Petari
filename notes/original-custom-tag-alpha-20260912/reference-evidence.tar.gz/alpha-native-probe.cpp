#include <algorithm>
#include <cassert>
#include <cstdint>
#include <cstddef>
#include <limits>
#include <cstdio>
using u8=std::uint8_t;using u32=std::uint32_t;using s32=std::int32_t;using f32=float;
class CustomTagAlphaCtrl {
public:
    CustomTagAlphaCtrl();

    void init(u32, f32, f32, s32, s32);
    u8 alpha() const;
    void update();
    bool isEnd() const;

    /* 0x00 */ s32 mDelay;
    /* 0x04 */ s32 mEndDelay;
    /* 0x08 */ s32 mFrame;
    /* 0x0C */ s32 mCharIndex;
    /* 0x10 */ s32 mWaitFrames;
    /* 0x14 */ u32 mLength;
    /* 0x18 */ bool mIsActive;
    /* 0x1C */ f32 mCharAlphaStep;
    /* 0x20 */ f32 mFrameAlphaStep;
};

CustomTagAlphaCtrl::CustomTagAlphaCtrl()
    : mDelay(0), mEndDelay(0), mFrame(0), mCharIndex(0), mWaitFrames(0), mLength(0), mIsActive(false), mCharAlphaStep(0.0f),
      mFrameAlphaStep(0.0f) {
}

void CustomTagAlphaCtrl::init(u32 length, f32 frameAlphaStep, f32 charAlphaStep, s32 delay, s32 endDelay) {
    if (frameAlphaStep == 0.0f) {
        mIsActive = false;
        return;
    }

    mFrame = -delay;
    mIsActive = true;
    mCharIndex = 0;
    mCharAlphaStep = charAlphaStep;
    mFrameAlphaStep = frameAlphaStep;
    mLength = length;
    mWaitFrames = 0;
    mDelay = delay;
    mEndDelay = endDelay;
}

u8 CustomTagAlphaCtrl::alpha() const {
    if (!mIsActive) {
        return 255;
    }

    f32 alpha = mFrameAlphaStep * (mFrame - mWaitFrames) - mCharIndex * mCharAlphaStep;
    return 255.0f * std::max(0.0f, std::min(1.0f, alpha));
}

void CustomTagAlphaCtrl::update() {
    s32 endFrame = mWaitFrames + mEndDelay + static_cast< s32 >((1.0f + mLength * mCharAlphaStep) / mFrameAlphaStep);
    mFrame = std::min(endFrame, mFrame + 1);
}

bool CustomTagAlphaCtrl::isEnd() const {
    if (!mIsActive) {
        return true;
    }

    s32 endFrame = mWaitFrames + mEndDelay + static_cast< s32 >((1.0f + mLength * mCharAlphaStep) / mFrameAlphaStep);
    return mFrame >= endFrame;
}

static_assert(sizeof(CustomTagAlphaCtrl)==0x24);
static_assert(offsetof(CustomTagAlphaCtrl,mCharIndex)==0xC);
static_assert(offsetof(CustomTagAlphaCtrl,mWaitFrames)==0x10);
static_assert(offsetof(CustomTagAlphaCtrl,mLength)==0x14);
static_assert(offsetof(CustomTagAlphaCtrl,mIsActive)==0x18);
static_assert(offsetof(CustomTagAlphaCtrl,mCharAlphaStep)==0x1C);
static_assert(offsetof(CustomTagAlphaCtrl,mFrameAlphaStep)==0x20);
int main(){
 CustomTagAlphaCtrl c;
 assert(c.alpha()==255 && c.isEnd() && !c.mIsActive);
 assert(c.mDelay==0 && c.mEndDelay==0 && c.mFrame==0 && c.mCharIndex==0 && c.mWaitFrames==0 && c.mLength==0);
 c.init(4,0.25f,0.5f,2,3);
 assert(c.mIsActive && c.mFrame==-2 && c.mDelay==2 && c.mEndDelay==3 && c.mLength==4);
 assert(c.alpha()==0 && !c.isEnd());
 c.update();c.update();assert(c.mFrame==0 && c.alpha()==0);
 c.update();assert(c.alpha()==63);c.update();assert(c.alpha()==127);
 c.mCharIndex=1;assert(c.alpha()==0);
 c.update();c.update();assert(c.alpha()==127);
 c.mWaitFrames=2;assert(c.alpha()==0);
 for(int i=0;i<40;i++)c.update();
 assert(c.mFrame==17 && c.isEnd() && c.alpha()==255);
 c.init(200,0.0f,5.0f,7,9);
 assert(!c.mIsActive && c.alpha()==255 && c.isEnd() && c.mFrame==17 && c.mLength==4);
 c.init(1,1.0f,0.0f,0,0);
 c.mFrameAlphaStep=std::numeric_limits<float>::quiet_NaN();assert(c.alpha()==255);
 puts("CustomTagAlphaCtrl native layout, delay, character alpha, wait, completion, disable and unordered clamp passed");
}
